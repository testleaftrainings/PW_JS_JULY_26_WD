//import { CreateLead } from "./createLead"
import {expect} from "@playwright/test"
import { playwrightWrapper } from "./pwWrapper";


export class VerifyLead extends playwrightWrapper{

    async VerifyFirstName(expectedfirstname:string){

        const firstName=await this.page.locator('#viewLead_firstName_sp').innerText()

        console.log("expected first name",expectedfirstname);
        
        console.log("Actual first name",firstName);
    
        //non-retry assertion
        expect (firstName).toBe(expectedfirstname)

        //retry assertion
        //verify the partial match using contains
     await expect(this.page.locator('#viewLead_firstName_sp')).toContainText(expectedfirstname)

    
       //verify using exact match
     await expect(this.page.locator('#viewLead_firstName_sp')).toHaveText(expectedfirstname)

     console.log("Successfully created Lead using Page Object Model");
     

    }
}