//import { HomePage } from "./homePage";
import { playwrightWrapper } from "./pwWrapper";

export class LeadPage extends playwrightWrapper{

    async ClickonCreateLeadButton(){

        //await this.page.locator('//a[text()="Create Lead"]').click()
        await this.click('//a[text()="Create Lead"]')
    }
    
}