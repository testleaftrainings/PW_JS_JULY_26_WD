//import { LoginPage } from "./loginPage";
import { playwrightWrapper } from "./pwWrapper";

export class WelcomePage extends playwrightWrapper{

    async ClickonCRMSFA (){

        //await this.page.locator('text=CRM/SFA').click()
        await this.click('text=CRM/SFA')


    }

    async ClickonLogout(){

        await this.page.locator('[type="submit"]').click()

    }
}