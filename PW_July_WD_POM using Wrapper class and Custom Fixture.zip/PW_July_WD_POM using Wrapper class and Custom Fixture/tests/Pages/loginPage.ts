/* loadurl()
entercredentials
clickingonLoginButton() */

import {chromium,Page} from "@playwright/test"
import { playwrightWrapper } from "./pwWrapper"
import {selectors} from "./locators"

export class LoginPage extends playwrightWrapper{

// //global property
// page:Page

// constructor(temppage:Page){  //temppage is the page reference from the constructor parameterization
//     this.page=temppage
// }


async loadUrl(url:string){
//await this.page.goto(url)
await this.loadApplication(url)
}

async enterCredentials(username:string,password:string){
//await this.page.locator('#username').fill(username)
//await this.page.locator('#password').fill(password)

//await this.clearAndFill('#username',username)
await this.clearAndFill(selectors.username,username)

//await this.clearAndFill('#password',password)
await this.clearAndFill(selectors.password,password)

}

async clickonLogin(){

//await this.page.locator('.decorativeSubmit').click()
//await this.click('.decorativeSubmit')
await this.click(selectors.clickonlogin)

}

// async closeBrowser(){

// await this.page.close()

//}


}

//browser instance 

// async function doLogin(){

// const browser=await chromium.launch({headless:false})
// const context=await browser.newContext()
// const page=await context.newPage()


// let lp=new LoginPage(page)
// await lp.loadUrl("https://leaftaps.com/opentaps/control/main")
// await lp.enterCredentials("democsr2","crmsfa")
// await lp.clickonLogin()
// await lp.closeBrowser()

// }

// doLogin()

