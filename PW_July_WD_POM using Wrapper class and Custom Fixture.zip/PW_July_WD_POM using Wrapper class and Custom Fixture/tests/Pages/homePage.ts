import { playwrightWrapper } from "./pwWrapper";
//import { WelcomePage } from "./welcomePage";

export class HomePage extends playwrightWrapper{

    async ClickonLeadsButton(){

    //await this.page.locator('//a[text()="Leads"]').click()
     await this.click('//a[text()="Leads"]')
    }

    async ClickonAccountsButton(){

    await this.page.locator('//a[text()="Contacts"]').click()


    }


}