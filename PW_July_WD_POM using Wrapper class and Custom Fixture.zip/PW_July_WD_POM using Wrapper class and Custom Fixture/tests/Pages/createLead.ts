//import { LeadPage } from "./leadPage";
import {faker} from "@faker-js/faker"
import { playwrightWrapper } from "./pwWrapper";

export class CreateLead extends playwrightWrapper{

 async EnterManditorydata(){

    let firstName=faker.person.firstName()

    //hardcoding the data
  //await this.page.locator('#createLeadForm_companyName').fill("Qeagle")
  //await this.page.locator('#createLeadForm_companyName').fill(faker.company.buzzNoun())
  await this.clearAndFill('#createLeadForm_companyName',faker.company.buzzNoun())

  //await this.page.locator('#createLeadForm_firstName').fill('Joseph')
  //await this.page.locator('#createLeadForm_firstName').fill(firstName)
  await this.clearAndFill('#createLeadForm_firstName',firstName)

  //await this.page.locator('#createLeadForm_lastName').fill('Vijay')
  //await this.page.locator('#createLeadForm_lastName').fill(faker.person.lastName())
  await this.clearAndFill('#createLeadForm_lastName',faker.person.lastName())

  return firstName

 }

 async ClickonCreateLeadSubmitButton(){

 //await this.page.locator('.smallSubmit').click()
 await this.click('.smallSubmit')

 }

}

