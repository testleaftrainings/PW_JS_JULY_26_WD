export const selectors={

    username:"#username",
    password:"#password",
    clickonlogin:".decorativeSubmit",

    accounts:{

        accountinputname:""
    }

   /* Accessing nested object,
    selectors.accounts.accountinputname */
    
}