import { Page } from "@playwright/test"

export class playwrightWrapper{


//global property
page:Page

constructor(temppage:Page){  //temppage is the page reference from the constructor parameterization
    this.page=temppage
}


async loadApplication(url:string){
try{
    await this.page.goto(url)
    console.log(`successfully loaded the URL,${url}`);
    }catch(error){
    console.log(`error loading the page at,${url}`);
    throw new Error(`failed to load the page,${url}`)
    }
}


async clearAndFill(locator:string,data:string){
 await this.page.locator(locator).clear()
 await this.page.locator(locator).fill(data)

}


async click(locator:string){
    await this.page.locator(locator).click()
}


    
    





}