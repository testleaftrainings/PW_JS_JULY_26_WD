import {test as base} from "@playwright/test"
import { LoginPage } from "../Pages/loginPage"
import { WelcomePage } from "../Pages/welcomePage"
import { HomePage } from "../Pages/homePage"
import { LeadPage } from "../Pages/leadPage"
import { CreateLead } from "../Pages/createLead"
import { VerifyLead } from "../Pages/verifyLead"

type myFixture={
loginPage:LoginPage
welcomePage:WelcomePage
homePage:HomePage
leadPage:LeadPage
createLeadpage:CreateLead
verifyLeadpage:VerifyLead
}

export const test=base.extend<myFixture>({

    loginPage:async ({page},use) => {
        const loginPage=new LoginPage(page)
        await use(loginPage)  
    },

    welcomePage:async ({page},use) => {
        const welcomePage=new WelcomePage(page)
        await use(welcomePage)  
    },

    homePage:async ({page},use) => {
        const homePage=new HomePage(page)
        await use(homePage)  
    },

    leadPage:async ({page},use) => {
        const leadPage=new LeadPage(page)
        await use(leadPage)  
    },

    createLeadpage:async ({page},use) => {
        const createLeadpage=new CreateLead(page)
        await use(createLeadpage)  
    },

    verifyLeadpage:async ({page},use) => {
        const verifyLeadpage=new VerifyLead(page)
        await use(verifyLeadpage)  
    }


})