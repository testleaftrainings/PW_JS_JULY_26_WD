//import {test} from "@playwright/test"
import {test} from "./Utils/customFixture"
//import { LoginPage } from "./Pages/loginPage"
import { LoginPage } from "./Pages/loginPage"
import { WelcomePage } from "./Pages/welcomePage"
import { HomePage } from "./Pages/homePage"
import { LeadPage } from "./Pages/leadPage"
import {CreateLead} from "./Pages/createLead"
import {VerifyLead} from "./Pages/verifyLead"

import dotenv from "dotenv"
import data from "../Data/leafTaps.json"

dotenv.config({path:'Data/prod.env'})

//test('Create lead using POM',async ({page}) => {
test('Create lead using POM',async ({

loginPage,
welcomePage,
homePage,
leadPage,
createLeadpage,
verifyLeadpage
}) => {

    // create object for login page
//let lp=new LoginPage(page)
await loginPage.loadUrl(process.env.LF_url as string)
await loginPage.enterCredentials(data[0].Username,data[0].Password)
await loginPage.clickonLogin()
//await lp.closeBrowser() //by default page fixture will close the browser

//create object for welcome page

//let wp=new WelcomePage(page)
await welcomePage.ClickonCRMSFA()

//create object for home page
//let hp=new HomePage(page)
await homePage.ClickonLeadsButton()

//create object for lead page
//let lpage=new LeadPage(page)
await leadPage.ClickonCreateLeadButton()

//create object for Create lead page
//let clp=new CreateLead(page)
let firstName=await createLeadpage.EnterManditorydata()
await createLeadpage.ClickonCreateLeadSubmitButton()

//create object for verify lead page
//let vp=new VerifyLead(page)
await verifyLeadpage.VerifyFirstName(firstName)
    
})